/* BearSSL sources are fetched at an immutable commit by 0020-stage-bearssl.sh. */
#if defined(ARM64_BOARD_CONFIG_M30LTE)
#include "m30_bearssl/src/hash/md5.c"
#endif
